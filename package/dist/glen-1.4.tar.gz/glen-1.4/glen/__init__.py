from .glen import event_detection


__version__ = "1.4"
